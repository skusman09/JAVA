package StudentApp;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Scanner;

import model.Student;
import service.Service;

public class StudentApp {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Collection<Student> studentList = new ArrayList<>();
		int ch;
		do {
			System.out.println("1. Add New Student Record\r\n"
					+ "2. Delete Student Record\r\n"
					+ "3. Show All Students Record\r\n"
					+ "4. Update an Existing Student Record\r\n"
					+ "5. Search Student by Rollnumber\n"
					+ "6. Search Student by Name\n"
					+ "0. Exit");

			System.out.println("enter Your Choice : ");
			ch = sc.nextInt();

			switch (ch) {
				case 1:
					System.out.println("Enter RollNumber Of Student : ");
					int roll = sc.nextInt();

					sc.nextLine();

					System.out.println("Enter Student Name : ");
					String name = sc.nextLine();

					System.out.println("Enter Student Contact Number : ");
					String contact = sc.next();

					Student st = Service.addStudent(roll, name, contact);

					studentList.add(st);
					break;

				case 2:
					System.out.println("Enter Roll-No : ");
					roll = sc.nextInt();
					Service.delStudent(roll, studentList);

					break;

				case 3:
					Service.showAllRecord(studentList);
					break;

				case 4:
					System.out.println("Enter Roll-No : ");
					roll = sc.nextInt();
					Student s1 = Service.updateStudent(roll, studentList);
					studentList.add(s1);
					break;

				case 5:
					System.out.println("Enter Roll-NO : ");
					roll = sc.nextInt();

					Service.searchStudent(roll, studentList);
					break;

				case 6:
					System.out.println("Enter Name : ");
					name = sc.next();

					Service.searchStudent(name, studentList);
					break;

				case 0:
					break;

				default:
					System.out.println("Invalid Choice \n  Enter Agin");
					ch = sc.nextInt();
			}
		} while (ch != 0);

		sc.close();
	}

}

package service;

import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;
import java.util.Scanner;

import model.Student; // Custom Class

public class Service {

	// 1. Add new Record
	public static Student addStudent(int roll, String n, String c) {
		System.out.println("Student Record Added \n");

		System.out.println("Enter Any Key to Continue...");
		try {
			System.in.read();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return new Student(roll, n, c);
	}

	// 2. delete a student record with rollnumber
	public static void delStudent(int rollNumber, Collection<Student> c) {
		boolean f = false;
		Iterator<Student> iterator = c.iterator();
		while (iterator.hasNext()) {
			Student student = iterator.next();
			if (student.getRollNumber() == rollNumber) {
				c.remove(student);
				System.out.println("Record Deleted Succussfully");
				f = true;
				break;
			}
		}

		if (!f) {
			System.out.println("Record Not Found...!");
		}

		System.out.println("Enter Any Key to Continue...");
		try {
			System.in.read();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// 3. Show all Record
	public static void showAllRecord(Collection<Student> collection) {
		collection.forEach(v -> System.out.println(v));
		System.out.println();

		System.out.println("Enter Any Key to Continue...");
		try {
			System.in.read();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// 4. update an existing student record
	public static Student updateStudent(int rollNumber, Collection<Student> collection) {
		Scanner sc = new Scanner(System.in);
		Iterator<Student> itr = collection.iterator();
		boolean f = false;
		Student s = null;
		while (itr.hasNext()) {

			Student student = itr.next();

			if (rollNumber == student.getRollNumber()) {
				System.out.println("Enter new name :");
				String _stu_name = sc.nextLine();

				System.out.println("Enter New Contact Number : ");
				String _contact = sc.next();

				s = new Student(rollNumber, _stu_name, _contact);

				f = true;
			}
		}

		if (!f)
			System.out.println("Record Not Found...!");
		sc.close();

		System.out.println("Enter Any Key to Continue...");
		try {
			System.in.read();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return s;
	}

	// 5. search by rollnumber
	public static void searchStudent(int rollNumber, Collection<Student> c) {
		boolean f = false;
		Iterator<Student> iterator = c.iterator();
		while (iterator.hasNext()) {
			Student student = iterator.next();
			if (student.getRollNumber() == rollNumber) {
				System.out.println(student);
				f = true;
				break;
			}
		}

		if (!f) {
			System.out.println("Record Not Found...!");
		}
	}

	// 6. search by "Name"
	public static void searchStudent(String name, Collection<Student> c) {
		boolean f = false;
		Iterator<Student> iterator = c.iterator();
		while (iterator.hasNext()) {
			Student student = iterator.next();
			if (student.getName().equalsIgnoreCase(name)) {
				System.out.println(student + "\n");
				f = true;
				break;
			}
		}

		if (!f) {
			System.out.println("Record Not Found...!");
		}
	}

}

package com.app;

public class BOB implements RBI {

	public void debit() {
		System.out.println("Debited From BOB");
	}

	public void credit() {
		System.out.println("Credited From BOB");

	}

}

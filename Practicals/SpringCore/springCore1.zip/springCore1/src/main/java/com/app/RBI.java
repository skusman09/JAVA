package com.app;

public interface RBI {
	void debit();

	void credit();
}

package com.app;

public class SBI implements RBI {

	public void debit() {
		System.out.println("Debited From SBI");
	}

	public void credit() {
		System.out.println("Credited From SBI");
	}

}

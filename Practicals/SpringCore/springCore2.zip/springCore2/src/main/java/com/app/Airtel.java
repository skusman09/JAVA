package com.app;

public class Airtel implements Sim {

	public void calling() {
		System.out.println("Calling With Airtel");
	}

	public void internet() {
		System.out.println("Using Airtel Internet");
	}

}

package com.app;

public interface Sim {
	void calling();

	void internet();
}

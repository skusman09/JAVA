package com.app;

public class Vi implements Sim {

	public void calling() {
		System.out.println("Calling With Vi");
	}

	public void internet() {
		System.out.println("Using Vi Internet");
	}
}

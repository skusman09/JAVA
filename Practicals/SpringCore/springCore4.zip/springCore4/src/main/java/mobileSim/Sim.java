package mobileSim;

import lombok.Data;

@Data
public class Sim {
	private String simId;
	private String simName;
	private String number;
}

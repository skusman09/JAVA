package com.app.springCore8;

import org.springframework.stereotype.Component;

//@Component
@Component("lbry")
public class Library {

}

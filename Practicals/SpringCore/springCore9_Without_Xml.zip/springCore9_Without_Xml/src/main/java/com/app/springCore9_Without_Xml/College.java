package com.app.springCore9_Without_Xml;

import org.springframework.stereotype.Component;

//@Component
@Component("colg")
public class College {
	public void temp() {
		System.out.println("This Is College \n");
	}
}

package com.app.springCore9_Without_Xml;

import org.springframework.stereotype.Component;

//@Component
@Component("lab")
public class Laboratory {
	public void temp() {
		System.out.println("This Is Laboratory \n");
	}
}

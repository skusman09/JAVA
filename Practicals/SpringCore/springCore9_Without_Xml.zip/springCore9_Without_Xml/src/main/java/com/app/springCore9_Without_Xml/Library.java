package com.app.springCore9_Without_Xml;

import org.springframework.stereotype.Component;

//@Component
@Component("lbry")
public class Library {
	public void temp() {
		System.out.println("This Is Library \n");
	}
}

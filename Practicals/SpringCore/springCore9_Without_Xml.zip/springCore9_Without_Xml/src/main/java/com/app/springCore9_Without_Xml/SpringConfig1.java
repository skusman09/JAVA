package com.app.springCore9_Without_Xml;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = "com.app.springCore9_Without_Xml")
public class SpringConfig1 {
}

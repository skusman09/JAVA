package reference_Using_Bean;

import lombok.Data;

@Data

public class Shopkeeper {
	public void showShopkeeper() {
		System.out.println("Im Shopkeeper");
	}
}

package withoutXML_Using_Bean_ReferenceClass;

public class City {

	public void showCity() {
		System.out.println("This Is City");
	}
}

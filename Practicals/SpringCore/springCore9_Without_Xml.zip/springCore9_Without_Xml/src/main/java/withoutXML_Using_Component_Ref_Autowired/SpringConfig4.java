package withoutXML_Using_Component_Ref_Autowired;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = "withoutXML_Using_Component_Ref_Autowired")

public class SpringConfig4 {
	
}

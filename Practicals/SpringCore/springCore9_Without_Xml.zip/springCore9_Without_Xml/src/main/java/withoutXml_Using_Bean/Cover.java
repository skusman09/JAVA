package withoutXml_Using_Bean;

public class Cover {
	public void showCover() {
		System.out.println("This Is Cover");
	}
}

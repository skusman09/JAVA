package withoutXml_Using_Bean;

public class Mobile {

	public void showMobile() {
		System.out.println("This Is Mobile");
	}
}

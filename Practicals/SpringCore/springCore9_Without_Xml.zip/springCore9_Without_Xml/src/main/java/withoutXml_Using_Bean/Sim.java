package withoutXml_Using_Bean;

public class Sim {
	public void showSim() {
		System.out.println("This Is Sim");
	}
}

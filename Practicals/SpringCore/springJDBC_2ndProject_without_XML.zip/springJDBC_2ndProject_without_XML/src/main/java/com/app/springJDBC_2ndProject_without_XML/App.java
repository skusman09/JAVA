package com.app.springJDBC_2ndProject_without_XML;

public class App {
	public static void main(String[] args) {
	}
}
